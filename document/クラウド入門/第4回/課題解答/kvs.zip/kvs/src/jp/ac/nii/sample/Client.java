package jp.ac.nii.sample;

import java.util.HashMap;

import org.apache.thrift.TException;
import org.apache.thrift.protocol.TBinaryProtocol;
import org.apache.thrift.protocol.TProtocol;
import org.apache.thrift.transport.TSocket;
import org.apache.thrift.transport.TTransport;
import org.apache.thrift.transport.TTransportException;

import jp.ac.nii.sample.kvs.SampleKVS;

// kvs��put��get���\�b�h���e�X�g����T���v���ł�
public class Client {
	public static void main(String[] args){
		// �ڑ�����T�[�o�[��ݒ肵�܂�
		TTransport transport = new TSocket("localhost", 9090);
		TProtocol protocol = new TBinaryProtocol(transport);
		try {
			transport.open();
			SampleKVS.Client client = new SampleKVS.Client(protocol);
			
			// �ۑ�����f�[�^�̍쐬
			HashMap<String, String> map = new HashMap<String, String>();
			map.put("id", "1");
			map.put("name", "hogehoge");
			map.put("entry", "fugafuga");
			
			// �f�[�^�̕ۑ�
			client.put("foo", map);
			System.out.println("set(foo, map)");
			
			// �ۑ������f�[�^�̎擾
			HashMap<String, String> result1 = (HashMap<String, String>) client.get("foo");
			System.out.println("get(foo): " + result1);
			
		} catch (TTransportException e) {
			e.printStackTrace();
		} catch (TException e) {
			e.printStackTrace();
		} finally {
			transport.close();
		}
	}
}
