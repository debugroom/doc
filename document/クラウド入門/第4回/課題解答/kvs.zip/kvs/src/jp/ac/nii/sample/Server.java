package jp.ac.nii.sample;

import java.util.HashMap;
import java.util.Map;

import org.apache.thrift.TException;
import org.apache.thrift.server.TServer;
import org.apache.thrift.server.TThreadPoolServer;
import org.apache.thrift.transport.TServerSocket;
import org.apache.thrift.transport.TServerTransport;
import org.apache.thrift.transport.TTransportException;

import jp.ac.nii.sample.kvs.SampleKVS;

public class Server {
	static class SampleKVSHandler implements SampleKVS.Iface {
		private HashMap<String, Map<String,String>> data = new HashMap<String, Map<String,String>>();
		
		// �f�[�^��ۑ����܂�
		@Override
		public void put(String key, Map<String, String> value) throws TException {
			data.put(key, value);
			System.out.println(data.size());
		}
		
		// �w�肵���L�[�ɑ΂���f�[�^���}�b�v�ŕԂ��܂�
		@Override
		public Map<String, String> get(String key) throws TException {
			Map<String, String> map = new HashMap<String, String>();
			return (data.containsKey(key)? data.get(key) : map);
		}

		// �ۑ�����Ă���f�[�^�̌�����Ԃ��܂�
		@Override
		public int getSize() throws TException {
			return data.size();
		}

	}
	
	// �T�[�o�[���N�����܂�
	public static void main(String[] args) {
		try{
			SampleKVSHandler handler = new SampleKVSHandler();
			SampleKVS.Processor processor = new SampleKVS.Processor(handler);
			TServerTransport transport = new TServerSocket(9090);
			TServer server = new TThreadPoolServer(processor, transport);
			server.serve();
		} catch (TTransportException e) {
			e.printStackTrace();
		}
	}
}
