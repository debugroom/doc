package cld56;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

public class Exc1 {

	public static class InverseMapper 
	extends Mapper<Object, Text, Text, Text>{

		static final Pattern div_space = Pattern.compile("[ \t]+");
		static final Pattern div_comma = Pattern.compile("[ \t]*,[ \t]*");

		public void map(Object key, Text value, Context context) 
				throws IOException, InterruptedException {

			String[] kv = div_space.split(value.toString(), 2);
			String[] bidders = div_comma.split(kv[1]);

            /*
             *  Fill with appropriate code here.
             */
		
		
		}
	}

	public static class InverseReducer 
	extends Reducer<Text, Text, Text, Text> {

		private String toCommaSeparatedList(Set<String> ss) {
			// { "a", "bb", "ccc" } ----> "a,b,c"
			String result = new String();
			boolean first = true;
			for (String s: ss) {
				result = result + s;
				if (!first) result = result + ",";
				first = false;
			}
			return result;
		}

		public void reduce(Text key, Iterable<Text> values, Context context) 
				throws IOException, InterruptedException {

			/*
			 *  Fill with appropriate code here.
			 */
		
		
		}
	}

	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();
		if (otherArgs.length != 2) {
			System.err.println("Usage: inverse <in> <out>");
			System.exit(2);
		}
		Job job = new Job(conf, "inverse");
		job.setJarByClass(Exc1.class);
		job.setMapperClass(InverseMapper.class);
		job.setReducerClass(InverseReducer.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);
		FileInputFormat.addInputPath(job, new Path(otherArgs[0]));
		FileOutputFormat.setOutputPath(job, new Path(otherArgs[1]));
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}
