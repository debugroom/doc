package kejiban.form;

public class ResForm {
	public String name;
	public String entry;
	
	public String cmd;
	public String start;
	public String pageSize;
}
