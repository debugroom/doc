# The Grinder 3.4
# HTTP script recorded by TCPProxy at 2011/01/28 16:25:53

from net.grinder.script import Test
from net.grinder.script.Grinder import grinder
from net.grinder.plugin.http import HTTPPluginControl, HTTPRequest
from HTTPClient import NVPair
connectionDefaults = HTTPPluginControl.getConnectionDefaults()
httpUtilities = HTTPPluginControl.getHTTPUtilities()

# To use a proxy server, uncomment the next line and set the host and port.
# connectionDefaults.setProxyServer("localhost", 8001)

# These definitions at the top level of the file are evaluated once,
# when the worker process is started.

connectionDefaults.defaultHeaders = \
  [ NVPair('User-Agent', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; .NET CLR 2.0.50727; InfoPath.1; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET CLR 1.1.4322; .NET4.0C; .NET4.0E)'),
    NVPair('Accept-Encoding', 'gzip, deflate'),
    NVPair('Accept-Language', 'ja'),
    NVPair('Referer', 'http://157.1.147.140/sample-kejiban/'),
    NVPair('Accept', 'image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/x-shockwave-flash, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, application/x-ms-application, application/x-ms-xbap, application/vnd.ms-xpsdocument, application/xaml+xml, */*'), ]

headers0= \
  [ ]

url0 = 'http://157.1.147.140:80'

# Create an HTTPRequest for each request, then replace the
# reference to the HTTPRequest with an instrumented version.
# You can access the unadorned instance using request101.__target__.
request101 = HTTPRequest(url=url0, headers=headers0)
request101 = Test(101, 'POST /').wrap(request101)

#request102 = HTTPRequest(url=url0, headers=headers0)
#request102 = Test(102, 'GET /').wrap(request102)


class TestRunner:
  """A TestRunner instance is created for each worker thread."""

  # A method for each recorded page.
  def page1(self):
    """POST / (requests 101-102)."""
    
    # Expecting 302 'Moved Temporarily'
    result = request101.POST('/sample-kejiban/',
      ( NVPair('name', 'nanashisan'),
        NVPair('entry', 'hogehoge'),
        NVPair('insert', 'CREATE'), ),
      ( NVPair('Content-Type', 'application/x-www-form-urlencoded'), ))

#    grinder.sleep(15)
#    request102.GET('/sample-kejiban/')

    return result

  def __call__(self):
    """This method is called for every run performed by the worker thread."""
    self.page1()      # POST / (requests 101-102)


def instrumentMethod(test, method_name, c=TestRunner):
  """Instrument a method with the given Test."""
  unadorned = getattr(c, method_name)
  import new
  method = new.instancemethod(test.wrap(unadorned), None, c)
  setattr(c, method_name, method)

# Replace each method with an instrumented version.
# You can call the unadorned method using self.page1.__target__().
instrumentMethod(Test(100, 'Page 1'), 'page1')
