/*
 * Copyright 2004-2008 the Seasar Foundation and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package kejiban.action;


import java.sql.Timestamp;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import kejiban.utility.PropertyLoader;

import kejiban.dao.ResDao;
import kejiban.entity.PageRequest;

import kejiban.entity.Res;
import kejiban.form.ResForm;

import org.apache.thrift.TException;
import org.seasar.struts.annotation.ActionForm;
import org.seasar.struts.annotation.Execute;

public class IndexAction {
	
	public List<Res> reses = new ArrayList<Res>();
	public Integer countRes;
	
	public Integer start;
	public Integer pageSize;
	
	// 設定ファイルを読み込みます
	private static final PropertyLoader config = new PropertyLoader("/config.properties");
	private static final List<String> serverHosts = config.getServerHosts();
	
	@ActionForm
	@Resource
	protected ResForm resForm;
	
    @Execute(validator = false, urlPattern="{start}-{cmd}")
	public String index() throws ParseException {
    	// ページの件数を取得します
    	PageRequest pageRequest = PageRequest.getPageRequest(resForm.cmd, resForm.start, resForm.pageSize);
    	start = pageRequest.getStart();
		pageSize = pageRequest.getPageSize();

		ResDao dao = new ResDao();
		// 現在の合計件数を取得します
		countRes = dao.gethashSize(serverHosts);
		// データを取得します
		reses = dao.getReses(start, pageSize, serverHosts);
		
        return "index.jsp";
	}
    
    @Execute(input = "index.jsp")
    public String insert() throws TException {    	
    	// 保存するデータを作成します
    	HashMap<String, String> map = new HashMap<String, String>();
    	map.put("name", resForm.name);
    	map.put("entry", resForm.entry);
    	
    	Timestamp timestamp = new Timestamp(System.currentTimeMillis());
    	map.put("date", timestamp.toString());
    	
    	ResDao dao = new ResDao();
    	Integer id = dao.getId(serverHosts);
    	map.put("id", id.toString());
    	
    	// 保存するサーバーを取得します
    	Integer targetHostNumber = id.hashCode() % serverHosts.size();
    	String targetHost = serverHosts.get(targetHostNumber);
    	
    	// データを保存します
    	dao.put(targetHost, map);
    	System.out.println(targetHostNumber);
    	return "?redirect=true";
    }
}
