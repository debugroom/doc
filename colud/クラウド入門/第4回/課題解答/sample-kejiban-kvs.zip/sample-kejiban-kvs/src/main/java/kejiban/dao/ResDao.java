package kejiban.dao;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import kejiban.entity.Res;
import kejiban.kvs.SampleKVS;

import org.apache.thrift.TException;
import org.apache.thrift.protocol.TBinaryProtocol;
import org.apache.thrift.protocol.TProtocol;
import org.apache.thrift.transport.TSocket;
import org.apache.thrift.transport.TTransport;
import org.apache.thrift.transport.TTransportException;
import org.seasar.framework.beans.util.Beans;

public class ResDao {

	// 現在保存されているデータの合計件数を返します
	public Integer gethashSize(List<String> serverHosts){
		Integer count = 0;
		for(String serverHost : serverHosts) {
			TTransport transport = new TSocket(serverHost, 9090);
			TProtocol protocol = new TBinaryProtocol(transport);
			try{
				transport.open();
				SampleKVS.Client client = new SampleKVS.Client(protocol);
				count += client.getSize();
			} catch (TTransportException e) {
				e.printStackTrace();
			} catch (TException e) {
				e.printStackTrace();
			} finally {
				transport.close();
			}
		}
		return count;
	}
	
	// 保存するidを返します
	public Integer getId(List<String> serverHosts) {
		return gethashSize(serverHosts) + 1;
	}
	
	// データを保存します
	public void put(String targetHost, HashMap<String, String> map){
		TTransport transport = new TSocket(targetHost, 9090);
		TProtocol protocol = new TBinaryProtocol(transport);
		try {
			transport.open();
			SampleKVS.Client client = new SampleKVS.Client(protocol);

			System.out.println("set(id, map)");
			client.put(map.get("id"), map);

		} catch (TTransportException e) {
			e.printStackTrace();
		} catch (TException e) {
			e.printStackTrace();
		} finally {
			transport.close();
		}
	}
	
	// 取得したデータのリストを返します
	public List<Res> getReses(Integer start, Integer pageSize, List<String> serverHosts) throws ParseException{
		
		List<Res> reses = new ArrayList<Res>();
		for(Integer i = start; i < pageSize + start; i++){
			Integer targetHostNumber = i.hashCode() % serverHosts.size();
			TTransport transport = new TSocket(serverHosts.get(targetHostNumber), 9090);
			TProtocol protocol = new TBinaryProtocol(transport);
			try {
				transport.open();
				SampleKVS.Client client = new SampleKVS.Client(protocol);
				HashMap<String, String> map = (HashMap<String, String>) client.get(i.toString());
				if (map.isEmpty()) {
					break;
				}
				Timestamp timestamp = new Timestamp(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").parse(map.get("date")).getTime());
				map.remove("date");
				Res res = Beans.createAndCopy(Res.class, map).execute();
				res.setDate(timestamp);
				reses.add(res);
				
			} catch (TTransportException e) {
				e.printStackTrace();
			} catch (TException e) {
				e.printStackTrace();
			} finally {
				transport.close();
			}
		}
		return reses;
	}
}
