package kejiban.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class PropertyLoader extends Properties{

	private static final long serialVersionUID = 1L;
	
	// 設定ファイルを読み込みます
	public PropertyLoader(String filename) {
		try {
			load(filename);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void load(String filename) throws Exception {
		InputStream inputStream = PropertyLoader.class.getResourceAsStream(filename);		
		load(inputStream);
	}
	
	// サーバーのＩＰアドレスのリストを取得します
	public List<String> getServerHosts() {
		List<String> ret = new ArrayList<String>();
		String[] list = getProperty("serverHosts").split(",");
		for(String serverHost : list){
			ret.add(serverHost);
		}
		return ret;
	}
}
