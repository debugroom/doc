package kejiban.form;

public class ResForm {
	public Integer id;
	public String name;
	public String entry;
	
	public String cmd;
	public String start;
	public String pageSize;
	
}
