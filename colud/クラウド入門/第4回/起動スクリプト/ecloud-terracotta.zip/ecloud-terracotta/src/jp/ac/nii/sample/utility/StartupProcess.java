package jp.ac.nii.sample.utility;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import com.xerox.amazonws.ec2.ReservationDescription.Instance;

//�����[�g�œ���̎菇�����s�����邽�߂̃��[�e�B���e�B�ł�
public class StartupProcess {
	// Tomcat(�A�v���P�[�V�����T�[�o)���N�����܂�
	public static void appServer(String appDnsName, String dbPrivateDnsName, Instance tcInstance, List<Instance> tcInstances, String srcDir, Boolean flag) throws IOException{
		// hibernate�̐ݒ���s���܂�
		try{
			// �e���v���[�g�t�@�C���̓ǂݍ���
            FileReader fr = new FileReader("src/hibernate-template.xml");
            BufferedReader br = new BufferedReader(fr);
        
            StringBuffer tmp_str = new StringBuffer();
            String tmp;
            while(( tmp = br.readLine()) != null){
            	tmp_str.append(tmp);
            	tmp_str.append("\n");
            }
            br.close();
            // �f�[�^�x�[�X�T�[�o�̐ڑ���IP�A�h���X���e���v���[�g�ɖ��ߍ��݂܂�
            String xmlValue = String.format(tmp_str.toString(), dbPrivateDnsName);
            // �ݒ�t�@�C���Ƃ��ď����o���܂�
            FileWriter fw = new FileWriter("src/hibernate.cfg.xml");
            fw.write(xmlValue);
            fw.close();
        }
        catch(IOException e){
            e.printStackTrace();
            System.exit(1);
        }
        
        if (flag == false) {
        	// ehcache�̐ݒ���s���܂�
        	try{
        		// �e���v���[�g�t�@�C���̓ǂݍ���
        		FileReader fr = new FileReader("src/ehcache-template.xml");
        		BufferedReader br = new BufferedReader(fr);
        		
        		StringBuffer tmp_str = new StringBuffer();
        		String tmp;
        		while(( tmp = br.readLine()) != null){
        			tmp_str.append(tmp);
        			tmp_str.append("\n");
        		}
        		br.close();
        		String xmlValue = String.format(tmp_str.toString(), tcInstance.getPrivateDnsName());
        		FileWriter fw = new FileWriter("src/ehcache.xml");
        		// �ݒ�t�@�C���Ƃ��ď����o���܂�
        		fw.write(xmlValue);
        		fw.close();
        	}
        	catch(IOException e){
        		e.printStackTrace();
        		System.exit(1);
        	}
        }
        ConfigurationModifier.scp(srcDir + "hibernate.cfg.xml", "root",
				appDnsName,
				"/opt/sample-kejiban/src/main/webapp/WEB-INF/classes/");
		System.out.println("send file hibernate.cfg.xml: " + appDnsName);
		
		ConfigurationModifier.scp(srcDir + "terracotta-license.key", "root",
				appDnsName,
				"/opt/sample-kejiban/src/main/webapp/WEB-INF/classes/");
		System.out.println("send file terracotta-license.key: " + appDnsName);
		
		ConfigurationModifier.ssh("root", appDnsName,
				"chmod 644 /opt/sample-kejiban/src/main/webapp/WEB-INF/classes/terracotta-license.key");
		System.out.println("chmod 644 terracotta-license.key: " + appDnsName);

		ConfigurationModifier.scp(srcDir + "ehcache.xml", "root",
				appDnsName,
				"/opt/sample-kejiban/src/main/webapp/WEB-INF/classes/");
		System.out.println("send file ehcache.xml: " + appDnsName);
		
		if (flag == true) {
			for(Instance inst: tcInstances){
				ConfigurationModifier.ssh("root", appDnsName,
						String.format("echo %1$1s %2$1s >> /etc/hosts", inst.getPrivateDnsName(), inst.getInstanceId()));
				System.out.println("created file hosts: " + appDnsName);
			}
		} else {
			ConfigurationModifier.ssh("root", appDnsName,
					String.format("echo %1$1s %2$1s >> /etc/hosts", tcInstance.getPrivateDnsName(), tcInstance.getInstanceId()));
			System.out.println("created file hosts: " + appDnsName);
		}
		ConfigurationModifier.ssh("root", appDnsName,
				"/etc/init.d/tomcat start");
		System.out.println("app server start: " + appDnsName);
	}
	
	// Tomcat(�A�v���P�[�V�����T�[�o)���N�����܂�
	public static void appServerRestart(List<Instance> appInstances, List<Instance> tcInstances, String srcDir) throws IOException {
		System.out.println("appServerRestart");
		// tc-config�̐ݒ���s���܂�
		String tmpFile = "src/hosts-template";
		try{
            FileReader fr = new FileReader(tmpFile);
            BufferedReader br = new BufferedReader(fr);
        
            StringBuffer tmp_str = new StringBuffer();
            String tmp;
            while(( tmp = br.readLine()) != null){
            	tmp_str.append(tmp);
            	tmp_str.append("\n");
            	for(Instance inst : tcInstances) {
            		tmp_str.append(String.format("%1$1s %2$1s", inst.getPrivateDnsName(), inst.getInstanceId()));
            		tmp_str.append("\n");
            	}
            }
            br.close();
            String confValue = tmp_str.toString();
            FileWriter fw = new FileWriter("src/hosts2");
            fw.write(confValue);
            fw.close();
        }
        catch(IOException e){
            e.printStackTrace();
            System.exit(1);
        }
        System.out.println("created hosts file");
		for (Instance inst : appInstances){
			ConfigurationModifier.scp(srcDir + "hosts2", "root",
					inst.getDnsName(),
					"/etc/");
			System.out.println("send file hosts: " + inst.getDnsName());
			
			ConfigurationModifier.ssh("root", inst.getDnsName(),
					"mv /etc/hosts2 /etc/hosts");
			System.out.println("mv hosts: " + inst.getDnsName());
			
			ConfigurationModifier.ssh("root", inst.getDnsName(),
					"chmod 644 /etc/hosts");
			System.out.println("mv hosts: " + inst.getDnsName());
	
			ConfigurationModifier.ssh("root", inst.getDnsName(),
					"/etc/init.d/tomcat stop");
			System.out.println("app server stop: " + inst.getDnsName());
			
			ConfigurationModifier.ssh("root", inst.getDnsName(),
					"/etc/init.d/tomcat start");
			System.out.println("app server start: " + inst.getDnsName());
		}
	}
	
	// Apache(Web�T�[�o)���N�����܂�
	public static void webServer(String webDnsName, String appPrivateDnsName) throws IOException{
		ConfigurationModifier.ssh("root", webDnsName,
				String.format("echo ProxyPass /sample-kejiban ajp://%1$1s:8009/sample-kejiban >> /etc/httpd/conf.d/proxy_ajp.conf", appPrivateDnsName));
		System.out.println("send file proxy_ajp.conf: " + webDnsName);

		ConfigurationModifier.ssh("root", webDnsName,
				"/etc/init.d/httpd restart");
		System.out.println("web server restart: " + webDnsName);
	}
	
	// nginx(���[�h�o�����T�[)���N�����܂�
	public static void lbServer(String lbDnsName, String webPrivateDnsName, String srcDir, Boolean flag) throws IOException{
		// nginx�̐ݒ���s���܂�
		String tmpFile = null;
		System.out.println(flag);
		if (flag == true) {
			tmpFile = "src/nginx.conf";
		} else {
			tmpFile = "src/nginx-template.conf";
		}
		
		try{
            FileReader fr = new FileReader(tmpFile);
            BufferedReader br = new BufferedReader(fr);
        
            StringBuffer tmp_str = new StringBuffer();
            String tmp;
            while(( tmp = br.readLine()) != null){
            	tmp_str.append(tmp);
            	tmp_str.append("\n");
            	if (tmp.endsWith("upstream backend {")) {
            		tmp_str.append(String.format("	server %1$1s;", webPrivateDnsName));
            		tmp_str.append("\n");
            	}
            }
            br.close();
            String confValue = tmp_str.toString();
            FileWriter fw = new FileWriter("src/nginx.conf");
            fw.write(confValue);
            fw.close();
        }
        catch(IOException e){
            e.printStackTrace();
            System.exit(1);
        }
        
        ConfigurationModifier.scp(srcDir + "nginx.conf", "root",
				lbDnsName,
				"/usr/local/nginx/conf/");
		System.out.println("send file nginx.conf: " + lbDnsName);
		
		ConfigurationModifier.ssh("root", lbDnsName,
				"/etc/init.d/nginx restart");
		System.out.println("lb server restart: " + lbDnsName);
	}
	
	public static void tcServer(Instance tcInstance, String srcDir) throws IOException{
		List<Instance> list = null;
		tcServer(tcInstance, list, srcDir, false);
	}
	
	public static void tcServer(Instance tcInstance, List<Instance> tcInstances, String srcDir, Boolean flag) throws IOException{
		
		// tc-config�̐ݒ���s���܂�
		String tmpFile = null;
		System.out.println(flag);
		if (flag == true) {
			tmpFile = "src/tc-config.xml";
			System.out.println("use tc-config.xml");
		} else {
			tmpFile = "src/tc-config-template.xml";
			System.out.println("use tc-config-template.xml");
		}
		
		try{
            FileReader fr = new FileReader(tmpFile);
            BufferedReader br = new BufferedReader(fr);
        
            StringBuffer tmp_str = new StringBuffer();
            String tmp;
            while(( tmp = br.readLine()) != null){
            	tmp_str.append(tmp);
            	tmp_str.append("\n");
            	if (flag == true) {
            		if (tmp.endsWith("<servers>")) {
            			tmp_str.append(String.format("<server host=\"%1$1s\" name=\"%1$1s\" bind=\"0.0.0.0\">", tcInstance.getInstanceId()));
            			tmp_str.append("\n");
            			tmp_str.append("<dso-port bind=\"0.0.0.0\">9510</dso-port>");
            			tmp_str.append("\n");
            			tmp_str.append("<jmx-port bind=\"0.0.0.0\">9520</jmx-port>");
            			tmp_str.append("\n");
            			tmp_str.append("<data>terracotta/server-data</data>");
            			tmp_str.append("\n");
            			tmp_str.append("<logs>terracotta/server-logs</logs>");
            			tmp_str.append("\n");
            			tmp_str.append("<statistics>terracotta/cluster-statistics</statistics>");
            			tmp_str.append("\n");
            			tmp_str.append("<l2-group-port>9530</l2-group-port>");
            			tmp_str.append("\n");
            			tmp_str.append("</server>");
            			tmp_str.append("\n");
            		}
            		if (tmp.endsWith("<mirror-groups>")) {
            			tmp_str.append(String.format("<mirror-group group-name=\"%1$1s\">", tcInstance.getInstanceId()));
            			tmp_str.append("\n");
            	        tmp_str.append("<members>");
            	        tmp_str.append("\n");
            	        tmp_str.append(String.format("<member>%1$1s</member>", tcInstance.getInstanceId()));
            	        tmp_str.append("\n");
            	        tmp_str.append("</members>");
            	        tmp_str.append("\n");
            	        tmp_str.append("</mirror-group>");
            	        tmp_str.append("\n");
            		}
            	}
            }
            br.close();
            String confValue;
            if (flag == false) {
            	confValue = String.format(tmp_str.toString(), tcInstance.getInstanceId());
            } else {
            	confValue = tmp_str.toString();
            }
            FileWriter fw = new FileWriter("src/tc-config.xml");
            fw.write(confValue);
            fw.close();
        }
        catch(IOException e){
            e.printStackTrace();
            System.exit(1);
        }
        System.out.println("created tc-config.xml");
        
        // hosts�̐ݒ���s���܂�
		if (flag == true) {
			for (Instance inst : tcInstances) {
				String tmpFile2 = "src/hosts-template";
				try{
					FileReader fr = new FileReader(tmpFile2);
					BufferedReader br = new BufferedReader(fr);
					
					StringBuffer tmp_str = new StringBuffer();
					String tmp;
					while(( tmp = br.readLine()) != null){
						tmp_str.append(tmp);
						tmp_str.append("\n");
						for (Instance inst2 : tcInstances) {
							String instId = inst2.getInstanceId();
							if (instId.equals(inst.getInstanceId())){
								tmp_str.append(String.format("127.0.0.1 %1$1s", instId));
								tmp_str.append("\n");
							} else {
								tmp_str.append(String.format("%1$1s %2$1s", inst2.getPrivateDnsName(), inst2.getInstanceId()));
								tmp_str.append("\n");
							}
						}
					}
					br.close();
					String confValue;
					confValue = tmp_str.toString();
					FileWriter fw = new FileWriter("src/hosts");
					fw.write(confValue);
					fw.close();
				}
				catch(IOException e){
					e.printStackTrace();
					System.exit(1);
				}
				System.out.println("created hosts file");
				
				ConfigurationModifier.scp(srcDir + "hosts", "root",
						inst.getDnsName(),
						"/etc/");
				System.out.println("send file hosts: " + inst.getDnsName());
				
				ConfigurationModifier.scp(srcDir + "tc-config.xml", "root",
						inst.getDnsName(),
						"/opt/terracotta/");
				System.out.println("send file tc-config.xml: " + inst.getDnsName());
			}
		} else {
			ConfigurationModifier.scp(srcDir + "tc-config.xml", "root",
					tcInstance.getDnsName(),
					"/opt/terracotta/");
			System.out.println("send file tc-config.xml: " + tcInstance.getDnsName());
			
			ConfigurationModifier.ssh("root", tcInstance.getDnsName(),
					String.format("echo 127.0.0.1 %1$1s >> /etc/hosts", tcInstance.getInstanceId()));
			System.out.println("send file hosts: " + tcInstance.getDnsName());
		}
		ConfigurationModifier.scp(srcDir + "terracotta-license.key", "root",
				tcInstance.getDnsName(),
				"/opt/terracotta/");
		System.out.println("send file terracotta-license.key: " + tcInstance.getDnsName());

		if (flag == false) {
			ConfigurationModifier.ssh("root", tcInstance.getDnsName(),
					String.format("/etc/init.d/terracotta start %1$1s", tcInstance.getInstanceId()));
			System.out.println("send file hosts: " + tcInstance.getDnsName());
		} else {
			for (Instance inst : tcInstances) {
				String instId2 = inst.getInstanceId();
				if (instId2 != tcInstance.getInstanceId()) {
					ConfigurationModifier.ssh("root", inst.getDnsName(),
							"/etc/init.d/terracotta stop");
					System.out.println("tc server stop: " + inst.getDnsName());
				}

				ConfigurationModifier.ssh("root", inst.getDnsName(),
						String.format("/etc/init.d/terracotta start %1$1s",inst.getInstanceId()));
				System.out.println("tc server start: " + inst.getDnsName());
			}
		}
	}
}
